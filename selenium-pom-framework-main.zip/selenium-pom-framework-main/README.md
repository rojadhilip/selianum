# selenium-pom-framework
This is an example of Selenium WebDriver Framework with Page Object Model design pattern. 
This framework is created with Selenium WebDriver (Java), Maven, TestNG, WebDriverManager, Extent Reports.

A Dummy Website application is used in this framework as the application under test. 
Simply pull the code for Dummy Website and you are good to go.
There is no need for any web server to run this application. The application is available at
https://github.com/cgjangid/dummy-local-website
